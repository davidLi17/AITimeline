/**
 * Runner - 代码块运行器
 * 
 * 检测页面中的代码块，为 JavaScript 代码块添加运行按钮
 */

(function() {
    'use strict';

    // 配置
    const CONFIG = {
        // 检测关键词（包含这些关键词的代码块才显示运行按钮）
        jsKeywords: ['let ', 'var ', 'const ', 'console.'],
        // pre 元素选择器
        preSelector: 'pre',
        // 防抖延迟
        debounceDelay: 300,
        // 已处理标记
        processedAttr: 'data-runner-initialized'
    };

    // 运行器实例缓存
    let runnerManagerInstance = null;
    // MutationObserver 实例
    let observer = null;
    // 防抖定时器
    let debounceTimer = null;

    /**
     * 获取 RunnerManager 实例
     */
    function getRunnerManager() {
        if (!runnerManagerInstance) {
            runnerManagerInstance = new window.RunnerManager();
        }
        return runnerManagerInstance;
    }

    /**
     * 检查代码是否包含 JavaScript 关键词
     * @param {string} code - 代码文本
     * @returns {boolean}
     */
    function isJavaScriptCode(code) {
        if (!code || typeof code !== 'string') return false;
        const normalizedCode = code.replace(/\u00A0/g, ' ');
        return CONFIG.jsKeywords.some(keyword => normalizedCode.includes(keyword));
    }

    /**
     * 获取代码块的代码文本
     * @param {HTMLElement} codeElement - code 元素
     * @returns {string}
     */
    function getCodeText(codeElement) {
        return (codeElement.textContent || '').replace(/\u00A0/g, ' ');
    }

    /**
     * 创建运行按钮
     * @param {HTMLElement} codeElement - code 元素
     * @param {HTMLElement} preElement - pre 元素
     * @returns {HTMLElement}
     */
    function createRunButton(codeElement, preElement) {
        const button = document.createElement('button');
        button.className = 'runner-code-run-btn';
        button.innerHTML = `
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7z"/>
            </svg>
            <span>Run</span>
        `;
        button.setAttribute('title', '运行代码');
        
        button.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            handleRunClick(codeElement, preElement, button);
        });
        
        return button;
    }

    /**
     * 创建结果面板
     * @returns {HTMLElement}
     */
    function createResultPanel() {
        const panel = document.createElement('div');
        panel.className = 'runner-result-panel';
        panel.innerHTML = `
            <div class="runner-result-header">
                <span class="runner-result-title">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="4 17 10 11 4 5"></polyline>
                        <line x1="12" y1="19" x2="20" y2="19"></line>
                    </svg>
                    Output
                </span>
                <div class="runner-result-actions">
                    <button class="runner-result-rerun" title="重新运行">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="23 4 23 10 17 10"></polyline>
                            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
                        </svg>
                    </button>
                    <button class="runner-result-close" title="关闭">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="18" y1="6" x2="6" y2="18"></line>
                            <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                    </button>
                </div>
            </div>
            <div class="runner-result-content"></div>
        `;
        return panel;
    }

    /**
     * 处理运行按钮点击
     * @param {HTMLElement} codeElement - code 元素
     * @param {HTMLElement} preElement - pre 元素
     * @param {HTMLElement} runButton - 运行按钮
     */
    async function handleRunClick(codeElement, preElement, runButton) {
        const code = getCodeText(codeElement);
        if (!code.trim()) return;

        // 获取或创建结果面板（在 pre 元素后面）
        let resultPanel = preElement.nextElementSibling;
        if (!resultPanel || !resultPanel.classList.contains('runner-result-panel')) {
            resultPanel = createResultPanel();
            preElement.parentNode.insertBefore(resultPanel, preElement.nextSibling);
            
            // 绑定重新运行按钮
            resultPanel.querySelector('.runner-result-rerun').addEventListener('click', () => {
                handleRunClick(codeElement, preElement, runButton);
            });
            
            // 绑定关闭按钮
            resultPanel.querySelector('.runner-result-close').addEventListener('click', () => {
                resultPanel.classList.remove('visible');
            });
        }

        const contentEl = resultPanel.querySelector('.runner-result-content');
        contentEl.innerHTML = '<div class="runner-result-loading">执行中...</div>';
        resultPanel.classList.add('visible');

        // 设置按钮为加载状态
        runButton.classList.add('loading');
        runButton.disabled = true;

        try {
            const manager = getRunnerManager();
            const outputs = [];

            await manager.run(code, 'javascript', {
                onOutput: (output) => {
                    outputs.push(output);
                },
                onError: (error) => {
                    outputs.push({ type: 'error', content: error });
                },
                onComplete: () => {
                    renderOutput(contentEl, outputs);
                }
            });
        } catch (error) {
            contentEl.innerHTML = `<div class="runner-output-error">${escapeHtml(error.message)}</div>`;
        } finally {
            runButton.classList.remove('loading');
            runButton.disabled = false;
        }
    }

    /**
     * 渲染输出结果
     * @param {HTMLElement} container - 容器元素
     * @param {Array} outputs - 输出数组
     */
    function renderOutput(container, outputs) {
        if (!outputs || outputs.length === 0) {
            container.innerHTML = '<div class="runner-output-empty">（无输出）</div>';
            return;
        }

        container.innerHTML = outputs.map(output => {
            const typeClass = `runner-output-${output.type || 'log'}`;
            const content = formatOutputContent(output.content);
            return `<div class="${typeClass}">${content}</div>`;
        }).join('');
    }

    /**
     * 格式化输出内容
     * @param {*} content - 输出内容
     * @returns {string}
     */
    function formatOutputContent(content) {
        if (content === undefined) return '<span class="runner-undefined">undefined</span>';
        if (content === null) return '<span class="runner-null">null</span>';
        if (typeof content === 'string') return escapeHtml(content);
        if (typeof content === 'object') {
            try {
                return escapeHtml(JSON.stringify(content, null, 2));
            } catch {
                return escapeHtml(String(content));
            }
        }
        return escapeHtml(String(content));
    }

    /**
     * HTML 转义
     * @param {string} str - 字符串
     * @returns {string}
     */
    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    /**
     * 为代码块初始化运行器
     * @param {HTMLElement} preElement - pre 元素
     */
    function initializeCodeBlock(preElement) {
        // 跳过已处理的
        if (preElement.hasAttribute(CONFIG.processedAttr)) return;
        preElement.setAttribute(CONFIG.processedAttr, 'true');

        // 检查 pre 下面是否有 code 子元素
        const codeElement = preElement.querySelector('code');
        if (!codeElement) return;

        // 检查是否是 JavaScript 代码
        const code = getCodeText(codeElement);
        if (!isJavaScriptCode(code)) return;

        // 创建运行按钮
        const runButton = createRunButton(codeElement, preElement);
        
        // 在 code 元素的上方插入运行按钮（作为 code 的前一个兄弟元素）
        codeElement.parentNode.insertBefore(runButton, codeElement);

        console.log('[Runner] Initialized code block');
    }

    /**
     * 扫描并处理所有代码块
     */
    function scanCodeBlocks() {
        const preElements = document.querySelectorAll(CONFIG.preSelector);
        preElements.forEach(preElement => {
            initializeCodeBlock(preElement);
        });
    }

    /**
     * 防抖扫描
     */
    function debouncedScan() {
        if (debounceTimer) {
            clearTimeout(debounceTimer);
        }
        debounceTimer = setTimeout(() => {
            scanCodeBlocks();
        }, CONFIG.debounceDelay);
    }

    /**
     * 初始化 MutationObserver
     */
    function initObserver() {
        if (observer) return;

        observer = new MutationObserver((mutations) => {
            let hasNewNodes = false;
            for (const mutation of mutations) {
                if (mutation.addedNodes.length > 0) {
                    hasNewNodes = true;
                    break;
                }
            }
            if (hasNewNodes) {
                debouncedScan();
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        console.log('[Runner] MutationObserver initialized');
    }

    /**
     * 初始化 Runner 模块
     */
    function initialize() {
        console.log('[Runner] Module loaded');
        
        // 初始扫描
        scanCodeBlocks();
        
        // 开始监听 DOM 变化
        initObserver();
    }

    /**
     * 清理资源
     */
    function cleanup() {
        if (observer) {
            observer.disconnect();
            observer = null;
        }
        if (debounceTimer) {
            clearTimeout(debounceTimer);
            debounceTimer = null;
        }
        if (runnerManagerInstance) {
            runnerManagerInstance.cleanup();
            runnerManagerInstance = null;
        }
    }

    // 暴露到全局
    if (typeof window !== 'undefined') {
        window.Runner = {
            getManager: getRunnerManager,
            scan: scanCodeBlocks,
            cleanup: cleanup
        };
    }

    // 自动初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }

})();
