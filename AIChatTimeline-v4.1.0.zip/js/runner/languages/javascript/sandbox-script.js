(function() {
    'use strict';
    
    var startTime = 0;
    
    function send(type, data) {
        try {
            window.parent.postMessage({ type: type, data: data }, '*');
        } catch (e) {
            console.error('[Sandbox] Failed to send:', type, e);
        }
    }
    
    function fmt(v) {
        if (v === null) return 'null';
        if (v === undefined) return 'undefined';
        if (typeof v === 'string') return v;
        if (typeof v === 'number' || typeof v === 'boolean') return String(v);
        if (typeof v === 'function') return v.toString();
        if (v instanceof Error) return v.stack || v.message;
        try { return JSON.stringify(v, null, 2); } catch (e) { return String(v); }
    }
    
    var _log = console.log;
    var _err = console.error;
    var _warn = console.warn;
    var _info = console.info;
    
    console.log = function() {
        var args = Array.prototype.slice.call(arguments);
        send('SANDBOX_OUTPUT', { level: 'log', data: args.map(fmt) });
        _log.apply(console, arguments);
    };
    console.error = function() {
        var args = Array.prototype.slice.call(arguments);
        send('SANDBOX_OUTPUT', { level: 'error', data: args.map(fmt) });
        _err.apply(console, arguments);
    };
    console.warn = function() {
        var args = Array.prototype.slice.call(arguments);
        send('SANDBOX_OUTPUT', { level: 'warn', data: args.map(fmt) });
        _warn.apply(console, arguments);
    };
    console.info = function() {
        var args = Array.prototype.slice.call(arguments);
        send('SANDBOX_OUTPUT', { level: 'info', data: args.map(fmt) });
        _info.apply(console, arguments);
    };
    
    window.onerror = function(msg, src, line, col, err) {
        send('SANDBOX_ERROR', { message: String(msg), line: line, stack: err ? err.stack : null });
        return true;
    };
    window.onunhandledrejection = function(e) {
        send('SANDBOX_ERROR', { message: 'Promise rejected: ' + e.reason });
    };
    
    function executeCode(code) {
        startTime = Date.now();
        
        try {
            var AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
            var fn = new AsyncFunction(code);
            
            fn().then(function() {
                setTimeout(function() {
                    send('SANDBOX_COMPLETE', { success: true, duration: Date.now() - startTime });
                }, 10);
            }).catch(function(e) {
                send('SANDBOX_ERROR', { message: e.message, stack: e.stack });
                send('SANDBOX_COMPLETE', { success: false, duration: Date.now() - startTime });
            });
        } catch (e) {
            send('SANDBOX_ERROR', { message: e.message, stack: e.stack });
            send('SANDBOX_COMPLETE', { success: false, duration: Date.now() - startTime });
        }
    }
    
    window.addEventListener('message', function(event) {
        if (!event.data || typeof event.data !== 'object') return;
        
        if (event.data.type === 'EXECUTE_CODE') {
            executeCode(event.data.code);
        }
    });
    
    send('SANDBOX_READY', { ready: true });
})();

