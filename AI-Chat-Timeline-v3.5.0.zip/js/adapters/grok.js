/**
 * Grok adapter
 * 适配 Grok (grok.com)
 */
class GrokAdapter extends SiteAdapter {
    matches(url) {
        return url.includes('grok.com');
    }

    getSiteName() {
        return 'grok';
    }

    /**
     * 查找对话容器
     * 使用通用的 LCA 算法查找最近公共祖先
     */
    findConversationContainer() {
        return ContainerFinder.findConversationContainer(this.getUserMessageSelector());
    }

    getUserMessageSelector() {
        // 用户消息：有 items-end class 且有 id 属性
        return '.items-end[id]';
    }

    generateTurnId(element, index) {
        // 使用元素的 id 属性作为唯一标识，如果没有则使用索引
        return element.id || `grok-${index}`;
    }

    extractText(element) {
        // 往下找 p 元素，class 包含 break-words 的文本
        const textElement = element.querySelector('p.break-words');
        if (textElement) {
            return textElement.textContent.trim();
        }
        return '';
    }

    isConversationRoute(pathname) {
        // Grok 对话 URL: /c/{id} 或分享页面 /share/{id}
        return pathname.includes('/c/') || pathname.includes('/share/');
    }

    extractConversationId(pathname) {
        // 从 URL 中提取对话 ID
        // 支持两种格式：
        // 1. https://grok.com/c/{conversationId}
        // 2. https://grok.com/share/{encodedId}
        
        // 匹配 /c/xxx 或 /share/xxx
        const match = pathname.match(/\/(c|share)\/([^/]+)/);
        if (match) {
            return match[2];
        }
        
        return null;
    }

    getTimelinePosition() {
        // 时间轴显示在左侧
        return 'left';
    }

    isDarkMode() {
        // 检查 Grok 的暗色模式
        // Grok 使用 html 元素的 class 控制主题 (dark/light)
        const html = document.documentElement;
        const body = document.body;
        
        // 检查常见的暗色模式标识
        return html.classList.contains('dark') || 
               body.classList.contains('dark') ||
               html.getAttribute('data-theme') === 'dark' ||
               body.getAttribute('data-theme') === 'dark';
    }

    /**
     * 初始化公式交互功能
     * Grok 使用 KaTeX 格式（与 DeepSeek、ChatGPT 相同）
     * @returns {FormulaManager|null}
     */
    initFormulaInteraction() {
        // 检查是否存在 FormulaManager 类
        if (typeof FormulaManager === 'undefined') {
            console.warn('FormulaManager is not loaded');
            return null;
        }
        
        // 创建并初始化 FormulaManager
        const formulaManager = new FormulaManager();
        formulaManager.init();
        
        return formulaManager;
    }
}

