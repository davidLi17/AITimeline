/**
 * Smart Enter - 配置常量
 * 
 * 定义智能 Enter 功能的配置参数
 */

const SMART_ENTER_CONFIG = {
    // 双击 Enter 的检测间隔（毫秒）
    // 300ms：快速双击才会发送，单击后稍等即换行
    DOUBLE_CLICK_INTERVAL: 300,
    
    // DOM 变化检测防抖延迟（毫秒）
    // 避免频繁触发附加逻辑
    DEBOUNCE_DELAY: 200,
    
    // 自定义属性标记（标识输入框已附加监听器）
    ATTACHED_ATTR: 'data-smart-input-attached',
    
    // 默认启用状态
    ENABLED_BY_DEFAULT: true,
    
    // 调试模式（使用全局配置）
    get DEBUG() {
        return typeof GLOBAL_DEBUG !== 'undefined' ? GLOBAL_DEBUG : false;
    },
    
    // MutationObserver 配置
    OBSERVER_CONFIG: {
        childList: true,
        subtree: true,
        attributes: false
    }
};

