/**
 * Smart Enter - 主入口
 * 
 * 智能 Enter 功能初始化
 * 
 * 功能：
 * - Enter 键：换行
 * - 快速双击 Enter：发送消息
 * 
 * 支持平台：
 * - ChatGPT
 * - 更多平台待添加...
 */

(function() {
    'use strict';
    
    // 等待 DOM 和依赖加载完成
    const initSmartEnter = () => {
        try {
            // 检查依赖是否加载
            if (typeof SmartEnterAdapterRegistry === 'undefined') {
                console.error('[SmartInputBox] SmartEnterAdapterRegistry not loaded');
                return;
            }
            
            if (typeof SmartEnterManager === 'undefined') {
                console.error('[SmartInputBox] SmartEnterManager not loaded');
                return;
            }
            
            // 获取当前页面的适配器
            const registry = window.smartEnterAdapterRegistry;
            if (!registry) {
                console.error('[SmartInputBox] Registry not initialized');
                return;
            }
            
            const adapter = registry.getAdapter();
            
            if (!adapter) {
                // 当前页面不匹配任何适配器，不启用功能
                return;
            }
            
            // 创建管理器实例
            const manager = new SmartEnterManager(adapter, {
                debug: SMART_ENTER_CONFIG.DEBUG
            });
            
            // 初始化
            manager.init();
            
            // 保存到全局（方便调试和外部控制）
            window.smartEnterManager = manager;
            
        } catch (error) {
            console.error('[SmartInputBox] Initialization failed:', error);
        }
    };
    
    // DOM 加载完成后初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initSmartEnter);
    } else {
        // DOM 已经加载完成
        initSmartEnter();
    }
    
})();

