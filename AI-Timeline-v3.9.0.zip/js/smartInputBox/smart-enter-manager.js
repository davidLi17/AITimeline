/**
 * Smart Enter Manager
 * 
 * 智能 Enter 管理器
 * 实现 Enter 换行 + 快速双击 Enter 发送
 */

class SmartEnterManager {
    constructor(adapter, options = {}) {
        if (!adapter) {
            throw new Error('SmartEnterManager requires an adapter');
        }
        
        this.adapter = adapter;
        this.config = {
            doubleClickInterval: options.doubleClickInterval || SMART_ENTER_CONFIG.DOUBLE_CLICK_INTERVAL,
            debug: options.debug || SMART_ENTER_CONFIG.DEBUG
        };
        
        // 功能启用状态（内存缓存，同步检查）
        this.isFeatureEnabled = false;
        
        // 状态
        this.state = {
            lastEnterTime: 0,
            enterCount: 0,
            savedSelection: null,  // 保存的光标位置/选区
            allowNextEnter: false  // 是否允许下一次 Enter 通过（用于发送）
        };
        
        // 定时器
        this.newlineTimer = null;
        this.debounceTimer = null;  // 防抖定时器
        
        // 观察器
        this.mutationObserver = null;
        
        // Storage 监听器
        this.storageListener = null;
    }
    
    /**
     * 初始化
     */
    async init() {
        // 1. 读取初始状态
        await this._loadInitialState();
        
        // 2. 监听 Storage 变化（实时响应用户开关）
        this._attachStorageListener();
        
        // 3. 始终附加到输入框（不管开关状态）
        this._attachToInputIfNeeded();
        
        // 4. 始终启动 DOM 监听（不管开关状态）
        this._startObserving();
    }
    
    /**
     * 从 Storage 加载初始状态
     */
    async _loadInitialState() {
        try {
            const result = await chrome.storage.local.get('smartEnterEnabled');
            this.isFeatureEnabled = result.smartEnterEnabled === true;
        } catch (e) {
            console.error('[SmartInputBox] Failed to load initial state:', e);
            this.isFeatureEnabled = false;  // 默认关闭
        }
    }
    
    /**
     * 附加 Storage 变化监听器
     */
    _attachStorageListener() {
        this.storageListener = (changes, areaName) => {
            if (areaName === 'local' && changes.smartEnterEnabled) {
                // 更新缓存状态
                this.isFeatureEnabled = changes.smartEnterEnabled.newValue === true;
            }
        };
        
        chrome.storage.onChanged.addListener(this.storageListener);
    }
    
    /**
     * 移除 Storage 变化监听器
     */
    _detachStorageListener() {
        if (this.storageListener) {
            chrome.storage.onChanged.removeListener(this.storageListener);
            this.storageListener = null;
        }
    }
    
    /**
     * 附加到输入框（带防抖）
     */
    _attachToInputIfNeeded() {
        try {
            const selector = this.adapter.getInputSelector();
            const input = document.querySelector(selector);
            
            if (input) {
                // 检查是否已附加（通过自定义属性）
                if (!input.hasAttribute(SMART_ENTER_CONFIG.ATTACHED_ATTR)) {
                    this._attachListener(input);
                    // 标记已附加
                    input.setAttribute(SMART_ENTER_CONFIG.ATTACHED_ATTR, 'true');
                }
            }
        } catch (e) {
            console.error('[SmartInputBox] Failed to attach to input:', e);
        }
    }
    
    /**
     * 防抖处理附加逻辑
     */
    _debouncedAttach() {
        // 清除之前的定时器
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
        }
        
        // 延迟执行
        this.debounceTimer = setTimeout(() => {
            this._attachToInputIfNeeded();
            this.debounceTimer = null;
        }, SMART_ENTER_CONFIG.DEBOUNCE_DELAY);
    }
    
    /**
     * 启动 DOM 监听
     */
    _startObserving() {
        try {
            // 避免重复创建
            if (this.mutationObserver) {
                return;
            }
            
            this.mutationObserver = new MutationObserver(() => {
                // 使用防抖，避免频繁触发
                this._debouncedAttach();
            });
            
            this.mutationObserver.observe(document.body, SMART_ENTER_CONFIG.OBSERVER_CONFIG);
        } catch (e) {
            console.error('[SmartInputBox] Failed to start observer:', e);
        }
    }
    
    /**
     * 停止 DOM 监听
     */
    _stopObserving() {
        if (this.mutationObserver) {
            this.mutationObserver.disconnect();
            this.mutationObserver = null;
        }
    }
    
    /**
     * 附加键盘监听器到输入框
     * @param {HTMLElement} inputElement - 输入框元素
     */
    _attachListener(inputElement) {
        if (!inputElement) return;
        
        // 创建绑定的事件处理器
        const handleKeyDown = this._handleKeyDown.bind(this, inputElement);
        const handleInput = this._handleInput.bind(this);
        
        // 附加 keydown 监听器（使用 capture 模式优先拦截）
        inputElement.addEventListener('keydown', handleKeyDown, { capture: true });
        
        // 附加 input 监听器（检测内容变化）
        inputElement.addEventListener('input', handleInput);
    }
    
    /**
     * 处理 input 事件（内容变化）
     * 在监听窗口期内，如果内容变化，取消当前的Enter处理
     */
    _handleInput() {
        // 如果有待执行的换行定时器，取消它
        if (this.newlineTimer) {
            clearTimeout(this.newlineTimer);
            this.newlineTimer = null;
            
            // 重置状态（内容变化了，之前的Enter操作失效）
            this._resetState();
        }
    }
    
    /**
     * 处理 Enter 键按下事件
     * @param {HTMLElement} inputElement - 输入框元素
     * @param {KeyboardEvent} e - 键盘事件
     */
    _handleKeyDown(inputElement, e) {
        // 只处理 Enter 键
        if (e.key !== 'Enter') {
            return;
        }
        
        // 如果按了 Shift/Ctrl/Alt/Meta，不处理（允许原生行为）
        if (e.shiftKey || e.ctrlKey || e.altKey || e.metaKey) {
            return;
        }
        
        // 如果是我们触发的 Enter（用于发送），允许通过
        if (this.state.allowNextEnter) {
            return;
        }
        
        // ✅ 核心：检查功能是否启用（同步检查缓存）
        if (!this.isFeatureEnabled) {
            // 功能未启用，不拦截，允许原生行为
            return;
        }
        
        // 功能已启用，拦截并处理
        e.preventDefault();
        e.stopPropagation();
        
        const now = Date.now();
        const timeSinceLastEnter = now - this.state.lastEnterTime;
        
        // 判断是否在检测窗口期内
        if (this.state.enterCount > 0 && timeSinceLastEnter < this.config.doubleClickInterval) {
            // 在窗口期内，增加计数
            this.state.enterCount++;
            
            // 检查是否达到双击（>= 2次）
            if (this.state.enterCount >= 2) {
                // 立即取消定时器
                if (this.newlineTimer) {
                    clearTimeout(this.newlineTimer);
                    this.newlineTimer = null;
                }
                
                // 立即触发发送
                this._triggerSend(inputElement);
                
                // 重置状态
                this._resetState();
            }
        } else {
            // 窗口期外，开始新的检测周期
            
            // 取消之前的定时器（如果有）
            if (this.newlineTimer) {
                clearTimeout(this.newlineTimer);
                this.newlineTimer = null;
            }
            
            // 保存当前光标位置
            this._saveSelection(inputElement);
            
            // 重置并开始计数
            this.state.enterCount = 1;
            this.state.lastEnterTime = now;
            
            // 启动检测定时器（300ms后执行）
            this.newlineTimer = setTimeout(() => {
                // 立即清除定时器引用（防止input事件重复处理）
                this.newlineTimer = null;
                
                // 只处理单击情况（双击已经立即处理了）
                if (this.state.enterCount === 1) {
                    // 检查输入框是否有内容
                    if (this.adapter.canSend(inputElement)) {
                        this._insertNewlineAtSavedPosition(inputElement);
                    }
                }
                
                // 重置状态
                this._resetState();
            }, this.config.doubleClickInterval);
        }
    }
    
    /**
     * 保存当前光标位置/选区
     * @param {HTMLElement} inputElement - 输入框元素
     */
    _saveSelection(inputElement) {
        try {
            const isContentEditable = inputElement.contentEditable === 'true';
            
            if (isContentEditable) {
                // contenteditable: 保存 Range 对象
                const selection = window.getSelection();
                if (selection.rangeCount > 0) {
                    this.state.savedSelection = {
                        type: 'range',
                        range: selection.getRangeAt(0).cloneRange()
                    };
                }
            } else {
                // textarea: 保存光标位置
                this.state.savedSelection = {
                    type: 'offset',
                    start: inputElement.selectionStart,
                    end: inputElement.selectionEnd
                };
            }
        } catch (e) {
            console.error('[SmartInputBox] Failed to save selection:', e);
        }
    }
    
    /**
     * 在保存的位置插入换行
     * @param {HTMLElement} inputElement - 输入框元素
     */
    _insertNewlineAtSavedPosition(inputElement) {
        if (!this.state.savedSelection) {
            this._insertNewline(inputElement);
            return;
        }
        
        try {
            const isContentEditable = inputElement.contentEditable === 'true';
            
            if (isContentEditable && this.state.savedSelection.type === 'range') {
                // 恢复选区并插入换行
                const selection = window.getSelection();
                selection.removeAllRanges();
                selection.addRange(this.state.savedSelection.range);
                
                this._insertNewline(inputElement);
            } else if (!isContentEditable && this.state.savedSelection.type === 'offset') {
                // 恢复光标位置并插入换行
                inputElement.selectionStart = this.state.savedSelection.start;
                inputElement.selectionEnd = this.state.savedSelection.end;
                
                this._insertNewline(inputElement);
            } else {
                // 类型不匹配，使用当前位置
                this._insertNewline(inputElement);
            }
        } catch (e) {
            console.error('[SmartInputBox] Failed to insert at saved position:', e);
            this._insertNewline(inputElement);
        }
    }
    
    /**
     * 插入换行符
     * @param {HTMLElement} inputElement - 输入框元素
     */
    _insertNewline(inputElement) {
        try {
            // 检查是否为 contenteditable 元素
            const isContentEditable = inputElement.contentEditable === 'true' || 
                                      inputElement.hasAttribute('contenteditable');
            
            if (isContentEditable) {
                // contenteditable 元素：模拟 Shift+Enter 按键事件
                // 让 ChatGPT 原生处理换行，确保格式正确
                
                // 确保元素有焦点
                if (document.activeElement !== inputElement) {
                    inputElement.focus();
                }
                
                // 创建 Shift+Enter 键盘事件
                const shiftEnterEvent = new KeyboardEvent('keydown', {
                    key: 'Enter',
                    code: 'Enter',
                    keyCode: 13,
                    which: 13,
                    shiftKey: true,
                    bubbles: true,
                    cancelable: true
                });
                
                // 触发事件，让 ChatGPT 原生处理换行
                inputElement.dispatchEvent(shiftEnterEvent);
                
                // 触发 keypress 和 keyup 事件
                const shiftEnterPress = new KeyboardEvent('keypress', {
                    key: 'Enter',
                    code: 'Enter',
                    keyCode: 13,
                    which: 13,
                    shiftKey: true,
                    bubbles: true,
                    cancelable: true
                });
                inputElement.dispatchEvent(shiftEnterPress);
                
                const shiftEnterUp = new KeyboardEvent('keyup', {
                    key: 'Enter',
                    code: 'Enter',
                    keyCode: 13,
                    which: 13,
                    shiftKey: true,
                    bubbles: true,
                    cancelable: true
                });
                inputElement.dispatchEvent(shiftEnterUp);
            } else {
                // 普通 textarea/input 元素
                
                // 获取当前选区
                const start = inputElement.selectionStart;
                const end = inputElement.selectionEnd;
                const value = inputElement.value;
                
                // 插入换行符
                const newValue = value.substring(0, start) + '\n' + value.substring(end);
                inputElement.value = newValue;
                
                // 恢复光标位置
                const newPosition = start + 1;
                inputElement.selectionStart = newPosition;
                inputElement.selectionEnd = newPosition;
                
                // 触发 input 事件
                inputElement.dispatchEvent(new Event('input', { bubbles: true }));
                inputElement.dispatchEvent(new Event('change', { bubbles: true }));
            }
        } catch (e) {
            console.error('[SmartInputBox] Failed to insert newline:', e);
        }
    }
    
    /**
     * 触发发送消息
     * 直接模拟普通的 Enter 键事件，让平台原生处理发送
     * @param {HTMLElement} inputElement - 输入框元素
     */
    _triggerSend(inputElement) {
        try {
            // 检查是否可以发送（输入框非空）
            if (!this.adapter.canSend(inputElement)) {
                return;
            }
            
            // 确保元素有焦点
            if (document.activeElement !== inputElement) {
                inputElement.focus();
            }
            
            // 设置标记，允许下一次 Enter 通过
            this.state.allowNextEnter = true;
            
            // 创建普通的 Enter 键事件（不带任何修饰键）
            const enterEvent = new KeyboardEvent('keydown', {
                key: 'Enter',
                code: 'Enter',
                keyCode: 13,
                which: 13,
                bubbles: true,
                cancelable: true
            });
            
            // 触发 Enter 事件，让平台原生处理发送
            inputElement.dispatchEvent(enterEvent);
            
            // 延迟清除标记，确保事件传播完成
            setTimeout(() => {
                this.state.allowNextEnter = false;
            }, 50);
        } catch (e) {
            console.error('[SmartInputBox] Failed to trigger send:', e);
        }
    }
    
    /**
     * 重置状态
     */
    _resetState() {
        this.state.lastEnterTime = 0;
        this.state.enterCount = 0;
        this.state.savedSelection = null;
        this.state.allowNextEnter = false;
        
        // 清除所有定时器
        if (this.newlineTimer) {
            clearTimeout(this.newlineTimer);
            this.newlineTimer = null;
        }
        
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
            this.debounceTimer = null;
        }
    }
    
    
    /**
     * 销毁管理器，清理所有监听器
     */
    destroy() {
        // 停止 DOM 监听
        this._stopObserving();
        
        // 移除 Storage 监听
        this._detachStorageListener();
        
        // 清除所有定时器和状态
        this._resetState();
    }
}

