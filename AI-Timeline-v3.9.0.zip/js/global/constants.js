/**
 * Global Constants
 * 
 * 全局共享常量配置
 * 包含所有 AI 平台的基础信息，供多个模块使用
 * 
 * 使用模块：
 * - Timeline（时间轴）
 * - StarredTab（收藏列表）
 * - SmartEnter（智能输入）
 */

// ==================== 全局配置 ====================

/**
 * 全局调试开关
 * 控制所有模块的调试日志输出
 */
const GLOBAL_DEBUG = false;

// ==================== AI 平台信息 ====================

/**
 * 支持的 AI 平台信息
 * 每个平台包含：域名列表、平台名称、logo 路径
 */
const SITE_INFO = [
    {
        sites: ['chatgpt.com', 'chat.openai.com'],
        name: 'ChatGPT',
        logoPath: 'images/logo/chatgpt.webp'
    },
    {
        sites: ['gemini.google.com'],
        name: 'Gemini',
        logoPath: 'images/logo/gemini.webp'
    },
    {
        sites: ['doubao.com'],
        name: '豆包',
        logoPath: 'images/logo/doubao.webp'
    },
    {
        sites: ['chat.deepseek.com'],
        name: 'DeepSeek',
        logoPath: 'images/logo/deepseek.webp'
    },
    {
        sites: ['yiyan.baidu.com'],
        name: '文心一言',
        logoPath: 'images/logo/wenxin.webp'
    },
    {
        sites: ['tongyi.com'],
        name: '通义千问',
        logoPath: 'images/logo/tongyi.webp'
    },
    {
        sites: ['kimi.com', 'kimi.moonshot.cn'],
        name: 'Kimi',
        logoPath: 'images/logo/kimi.webp'
    },
    {
        sites: ['yuanbao.tencent.com'],
        name: '元宝',
        logoPath: 'images/logo/yuanbao.webp'
    },
    {
        sites: ['grok.com'],
        name: 'Grok',
        logoPath: 'images/logo/grok.webp'
    }
];

/**
 * 获取完整的 siteNameMap
 * 将数组结构的 SITE_INFO 转换为域名映射对象，并将 logoPath 转换为完整的 chrome.runtime URL
 * 
 * @returns {Object} 域名到平台信息的映射对象，格式：{ 'domain': { name, logo } }
 */
function getSiteNameMap() {
    const map = {};
    for (const platform of SITE_INFO) {
        const info = {
            name: platform.name,
            logo: chrome.runtime.getURL(platform.logoPath)
        };
        // 为每个域名创建映射
        for (const site of platform.sites) {
            map[site] = info;
        }
    }
    return map;
}

/**
 * 根据 URL 获取网站信息
 * 使用 includes 匹配，支持 www 等前缀
 * 
 * @param {string} url - 网站 URL
 * @returns {Object} { name, logo }
 */
function getSiteInfoByUrl(url) {
    try {
        const urlObj = new URL(url);
        const hostname = urlObj.hostname;
        
        // 遍历所有平台，使用 includes 匹配
        for (const platform of SITE_INFO) {
            for (const site of platform.sites) {
                if (hostname.includes(site)) {
                    return {
                        name: platform.name,
                        logo: chrome.runtime.getURL(platform.logoPath)
                    };
                }
            }
        }
        
        // 未匹配到任何平台，返回默认值
        return { name: hostname, logo: null };
    } catch (e) {
        return { name: 'Unknown', logo: null };
    }
}

