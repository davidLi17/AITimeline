/**
 * Smart Input Box Settings Tab - 智能输入框设置
 * 
 * 功能：
 * - 提供开关控制智能输入框功能
 * - 单击 Enter 换行，快速双击 Enter 发送
 */

class SmartInputBoxTab extends BaseTab {
    constructor() {
        super();
        this.id = 'smartInputBox';
        this.name = chrome.i18n.getMessage('xmvkpz');
        this.icon = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
            <line x1="9" y1="9" x2="15" y2="9"/>
            <line x1="9" y1="13" x2="15" y2="13"/>
            <line x1="9" y1="17" x2="15" y2="17"/>
        </svg>`;
    }
    
    /**
     * 渲染设置内容
     */
    render() {
        const container = document.createElement('div');
        container.className = 'smart-input-box-settings';
        
        container.innerHTML = `
            <div class="setting-section">
                <div class="setting-item">
                    <div class="setting-info">
                        <div class="setting-label">${chrome.i18n.getMessage('kvzmxp')}</div>
                        <div class="setting-hint">
                            ${chrome.i18n.getMessage('mxpzvk')}
                        </div>
                    </div>
                    <label class="toggle-switch">
                        <input type="checkbox" id="smart-input-toggle">
                        <span class="toggle-slider"></span>
                    </label>
                </div>
            </div>
        `;
        
        return container;
    }
    
    /**
     * Tab 激活时加载状态
     */
    async mounted() {
        super.mounted();
        
        const checkbox = document.getElementById('smart-input-toggle');
        if (!checkbox) return;
        
        // 读取当前状态
        try {
            const result = await chrome.storage.local.get('smartEnterEnabled');
            checkbox.checked = result.smartEnterEnabled === true;
        } catch (e) {
            console.error('[SmartInputBoxTab] Failed to load state:', e);
            checkbox.checked = false;
        }
        
        // 监听开关变化
        this.addEventListener(checkbox, 'change', async (e) => {
            try {
                const enabled = e.target.checked;
                
                // 保存到 Storage
                await chrome.storage.local.set({ smartEnterEnabled: enabled });
            } catch (e) {
                console.error('[SmartInputBoxTab] Failed to save state:', e);
                
                // 保存失败，恢复checkbox状态
                checkbox.checked = !checkbox.checked;
            }
        });
    }
    
    /**
     * Tab 卸载时清理
     */
    unmounted() {
        super.unmounted();
    }
}

